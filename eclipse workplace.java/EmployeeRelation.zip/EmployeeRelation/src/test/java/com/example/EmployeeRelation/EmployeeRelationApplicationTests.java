package com.example.EmployeeRelation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeRelationApplicationTests {

	@Test
	void contextLoads() {
	}

}
