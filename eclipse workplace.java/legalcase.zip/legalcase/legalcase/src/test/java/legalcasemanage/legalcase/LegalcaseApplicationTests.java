package legalcasemanage.legalcase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LegalcaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
