package legalcasemanage.legalcase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LegalcaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(LegalcaseApplication.class, args);
	}

}
