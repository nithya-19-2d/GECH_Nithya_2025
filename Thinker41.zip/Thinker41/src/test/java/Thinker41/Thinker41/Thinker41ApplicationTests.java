package Thinker41.Thinker41;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Thinker41ApplicationTests {

	@Test
	void contextLoads() {
	}

}
